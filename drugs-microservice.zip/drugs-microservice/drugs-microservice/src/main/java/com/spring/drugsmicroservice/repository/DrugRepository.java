package com.spring.drugsmicroservice.repository;

import com.spring.drugsmicroservice.model.Drugs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DrugRepository extends JpaRepository<Drugs,String> {
    Optional<Drugs> findBydrugName(String name);
}
