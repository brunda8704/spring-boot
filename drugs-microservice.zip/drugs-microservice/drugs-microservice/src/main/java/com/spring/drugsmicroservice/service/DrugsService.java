package com.spring.drugsmicroservice.service;

import com.spring.drugsmicroservice.exception.DrugBadRequestException;
import com.spring.drugsmicroservice.exception.DrugNotFoundException;
import com.spring.drugsmicroservice.model.Drugs;
import com.spring.drugsmicroservice.repository.DrugLocationRepository;
import com.spring.drugsmicroservice.repository.DrugRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DrugsService {

    @Autowired
    private DrugRepository drugRepository;

    @Autowired
    private DrugLocationRepository drugLocationRepository;


    public Drugs getDrugById(String drugId) {
        Optional<Drugs> opt = this.drugRepository.findById(drugId);
        if (opt.isEmpty()) {
            return opt.get();
        } else {
            throw new DrugNotFoundException("Drug with drudId:" + drugId + "doesn't exist");

        }

    }

    public Drugs getDrugByName(String drugName) {

        Optional<Drugs> opt = drugRepository.findBydrugName(drugName);
        if (opt.isEmpty()) {
            return opt.get();
        } else {
            throw new DrugNotFoundException("Drug with drugName:" + drugName + "doesn't exist");

        }
    }

//    public Drugs createNewDrug(Drugs drugsRequest) {
//        if (drugsRequest.getDrugId() != null && drugsRequest.getDrugName() != null)
//
//       {
//            if (!drugsRequest.getDrugId().isEmpty()) {
//                if (!drugsRequest.getDrugName().isEmpty()) {
//
//                    return this.drugRepository.save(drugsRequest);
//                }
//
//                    else {
//                    throw new DrugBadRequestException("Drug Name cannot be empty string.");
//                }
//            } else {
//                throw new DrugBadRequestException("Drug Id cannot be empty string.");
//            }
//        }
//        throw new DrugBadRequestException("Drug Id and Drug Name are mandatory.");
//    }
}
