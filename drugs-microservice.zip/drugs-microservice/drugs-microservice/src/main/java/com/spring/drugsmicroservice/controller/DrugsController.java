package com.spring.drugsmicroservice.controller;

import com.spring.drugsmicroservice.exception.DrugNotFoundException;
import com.spring.drugsmicroservice.model.Drugs;
import com.spring.drugsmicroservice.service.DrugsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RequestMapping("/api/drugs")
@RestController

public class DrugsController {
    @Autowired
    private DrugsService drugsService;



    @GetMapping("/searchDrugsByID/{Drug_Id}")
    public ResponseEntity<?> getDrugById(@PathVariable("drugId") String drugId)  {
        Drugs drugs=this.drugsService.getDrugById(drugId);

        return new ResponseEntity<>(drugs,HttpStatus.OK);
    }


    @GetMapping("/searchDrugsByName/{Drug_Name}")
    public ResponseEntity<?> getDrugByName(@PathVariable("drugName") String drugName)  {
        Drugs drugs=this.drugsService.getDrugByName(drugName);

        return new ResponseEntity<>(drugs,HttpStatus.OK);
    }


//    @PostMapping
//    public ResponseEntity<?> createNewDrug(@RequestBody Drugs drugsRequest) {
//        Drugs createdDrug = this.drugsService.createNewDrug(drugsRequest);
//        return new ResponseEntity<>(createdDrug, HttpStatus.CREATED);
//    }

}
