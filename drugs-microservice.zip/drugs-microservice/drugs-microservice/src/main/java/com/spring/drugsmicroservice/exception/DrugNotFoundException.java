package com.spring.drugsmicroservice.exception;

public class DrugNotFoundException extends RuntimeException {




    public DrugNotFoundException(String errorMessage)
    {
        super(errorMessage);
    }
}
