package com.spring.drugsmicroservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.text.SimpleDateFormat;
import java.util.Date;


@ControllerAdvice
public class DrugExceptionHandler extends ResponseEntityExceptionHandler {

    private static final String DATE_FORMAT = "yyyy.MM.dd'T'HH.mm.ss.SSSXXX";

    @ExceptionHandler(value = DrugNotFoundException.class)
    public ResponseEntity<?> handleStudentNotFoundException(DrugNotFoundException drugNotFoundException) {

        GenericException genericException = new GenericException();
        genericException.setErrorMessage(drugNotFoundException.getMessage());
        genericException.setErrorStatusCode(404);
        genericException.setErrorTimestamp(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
        return new ResponseEntity<>(genericException, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = DrugBadRequestException.class)
    public ResponseEntity<?> handleStudentBadRequestException(DrugBadRequestException drugBadRequestException) {

        GenericException genericException = new GenericException();
        genericException.setErrorMessage(drugBadRequestException.getMessage());
        genericException.setErrorStatusCode(400);
        genericException.setErrorTimestamp(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
        return new ResponseEntity<>(genericException, HttpStatus.BAD_REQUEST);
    }

}

