package com.spring.drugsmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrugsMicroserviceApplication {

	public static void main(String[] args) {

		SpringApplication.run(DrugsMicroserviceApplication.class, args);
	}

}
