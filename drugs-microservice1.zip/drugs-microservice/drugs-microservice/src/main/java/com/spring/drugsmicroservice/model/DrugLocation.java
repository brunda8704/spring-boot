package com.spring.drugsmicroservice.model;


import jakarta.persistence.*;

@Entity
@Table(name="DrugLocation")
public class DrugLocation {

    @Id
    @Column(name = "serial_id", nullable = false)
    private String serialId;

    @Column(name = "location")
    private String location;

    @Column(name = "quantity")
    private int quantity;


//  @OneToOne(cascade= CascadeType.ALL)
//  @JoinColumn(name = "drugId" ,referencedColumnName = "drugId")
//    @Column(name = "drugId")
    private String drugId;

    public String getSerialId() {
        return serialId;
    }

    public void setSerialId(String serialId) {
        this.serialId = serialId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDrugId() {
        return drugId;
    }

    public void setDrugId(String drugId) {
        this.drugId = drugId;
    }

    @Override
    public String toString() {
        return "DrugLocation{" +
                "serialId='" + serialId + '\'' +
                ", location='" + location + '\'' +
                ", quantity=" + quantity +
                ", drugId='" + drugId + '\'' +
                '}';
    }
}
