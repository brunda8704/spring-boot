package com.spring.drugsmicroservice.controller;

import com.spring.drugsmicroservice.exception.DrugNotFoundException;
import com.spring.drugsmicroservice.model.Drugs;
import com.spring.drugsmicroservice.repository.DrugRepository;
import com.spring.drugsmicroservice.service.DrugsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.hibernate.sql.ast.SqlTreeCreationLogger.LOGGER;


@RequestMapping("/api/drugs")
@RestController

public class DrugsController {
    @Autowired
    private DrugsService drugsService;
    @Autowired
    private DrugRepository drugRepository;


    @GetMapping("/searchDrugById/{drugId}")
    public ResponseEntity<?> getDrugById(@PathVariable("drugId") String drugId)  {
        Drugs drugs=this.drugsService.getDrugById(drugId);

        return new ResponseEntity<>(drugs,HttpStatus.OK);
    }


    @GetMapping("/searchDrugByName/{drugName}")
    public ResponseEntity<?> getDrugByName(@PathVariable("drugName") String drugName)  {
        Drugs drugs=this.drugsService.getDrugByName(drugName);

        return new ResponseEntity<>(drugs,HttpStatus.OK);
    }



//@PostMapping
//public ResponseEntity<?> createDrug(@RequestBody Drugs drugsRequest) {
//    Drugs createdDrug = this.drugsService.createDrug(drugsRequest);
//    return new ResponseEntity<>(createdDrug, HttpStatus.CREATED);
//}


}
