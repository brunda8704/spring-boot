package com.spring.drugsmicroservice.exception;

public class DrugBadRequestException extends RuntimeException{
    public DrugBadRequestException(String errorMessage)
    {
        super(errorMessage);
    }
}
